import {
  SoalUjianMingguan,
  HasilUjianKruMingguan,
  ExamWeek,
  Division,
  PilarKompetensi,
} from '../types';

// ============================================================================
// BANK SOAL MINGGUAN HARA CHICKEN
// Aturan: kru hanya diuji materi jobdesk-nya sendiri + SOP Umum (divisi 'Semua').
// Seluruh jawaban jobdesk merujuk ke src/lib/sopData.ts (kode SOP tercantum).
// Catatan: ini bank awal. Tambahkan soal baru lewat helper pg() / essay() / karakter().
// ============================================================================

type Opsi = [string, string, string, string];
type Dimensi = 'integritas' | 'ketahanan_stres' | 'fokus_pelanggan' | 'disiplin_sop' | 'kerjasama_tim';

const WEEK_NUM: Record<ExamWeek, 1 | 2 | 3 | 4> = {
  MINGGU_1: 1,
  MINGGU_2: 2,
  MINGGU_3: 3,
  MINGGU_4: 4,
};

const LABELS = ['A', 'B', 'C', 'D'] as const;

function pg(
  id: string,
  minggu: ExamWeek,
  divisi: Division | 'Semua',
  pilar: PilarKompetensi,
  kode: string | undefined,
  topik: string,
  pertanyaan: string,
  opsi: Opsi,
  benar: 'A' | 'B' | 'C' | 'D',
  pembahasan: string,
  kesulitan: 'Mudah' | 'Sedang' | 'Sulit' = 'Sedang'
): SoalUjianMingguan {
  return {
    id,
    minggu,
    mingguNomor: WEEK_NUM[minggu],
    divisi,
    tipe: 'PILIHAN_GANDA',
    topik,
    pilar_kompetensi: pilar,
    tingkat_kesulitan: kesulitan,
    kode_sop: kode,
    pertanyaan,
    opsi: opsi.map((teks, i) => ({ label: LABELS[i], teks })),
    jawaban_benar: benar,
    pembahasan_sop: pembahasan,
    bobot: 10,
  };
}

function essay(
  id: string,
  minggu: ExamWeek,
  divisi: Division | 'Semua',
  pilar: PilarKompetensi,
  kode: string | undefined,
  topik: string,
  pertanyaan: string,
  skenario: string,
  kataKunci: string[],
  pembahasan: string
): SoalUjianMingguan {
  return {
    id,
    minggu,
    mingguNomor: WEEK_NUM[minggu],
    divisi,
    tipe: 'ESSAY_HOTS',
    topik,
    pilar_kompetensi: pilar,
    tingkat_kesulitan: 'Sulit',
    kode_sop: kode,
    pertanyaan,
    skenario_konteks: skenario,
    kata_kunci_essay: kataKunci,
    pembahasan_sop: pembahasan,
    bobot: 20,
  };
}

function karakter(
  id: string,
  minggu: ExamWeek,
  pilar: PilarKompetensi,
  topik: string,
  skenario: string,
  pertanyaan: string,
  opsi: { teks: string; dimensi: Dimensi; poin: number; deskripsi: string }[]
): SoalUjianMingguan {
  return {
    id,
    minggu,
    mingguNomor: WEEK_NUM[minggu],
    divisi: 'Semua',
    tipe: 'KARAKTERISTIK_PSIKOLOGIS',
    topik,
    pilar_kompetensi: pilar,
    pertanyaan,
    skenario_konteks: skenario,
    opsi: opsi.map((o, i) => ({
      label: LABELS[i],
      teks: o.teks,
      profil_trait: { dimensi: o.dimensi, poin: o.poin, deskripsi: o.deskripsi },
    })),
    bobot: 0,
  };
}

const W1: ExamWeek = 'MINGGU_1';
const W2: ExamWeek = 'MINGGU_2';
const W3: ExamWeek = 'MINGGU_3';
const W4: ExamWeek = 'MINGGU_4';
const JOB: PilarKompetensi = 'sop_jobdesk';
const ATUR: PilarKompetensi = 'peraturan_perusahaan';
const KARK: PilarKompetensi = 'karakter_integritas';
const VISI: PilarKompetensi = 'visi_misi_hara';

export const BANK_SOAL_MINGGUAN: SoalUjianMingguan[] = [
  // ========================= KITCHEN =========================
  pg('k1a', W1, 'Kitchen', JOB, 'HC-SOP-KIT-01', 'Menanak Nasi', 'Berapa lama nasi dibiarkan tanak setelah tombol COOK kembali (jegleg) sebelum dipindah ke magicom?', ['5 menit', '10 menit', '15 menit', '30 menit'], 'C', 'Setelah jegleg, nasi dibiarkan sekitar 15 menit agar tanak sempurna. Nasi tidak boleh dibiarkan di rice cooker lebih dari 30 menit.', 'Mudah'),
  pg('k1b', W1, 'Kitchen', JOB, 'HC-SOP-KIT-01', 'Takaran Air Nasi', 'Perbandingan baku air untuk 4 cup beras adalah...', ['4 cup beras : 4 cup air', '4 cup beras : 5 cup air', '4 cup beras : 6 cup air', '4 cup beras : 8 cup air'], 'B', 'Perbandingan baku: 3:4, 4:5, 5:6, 6:8 (beras : air).'),
  pg('k2a', W2, 'Kitchen', JOB, 'HC-SOP-KIT-02', 'Goreng Ayam', 'Standar goreng ayam: suhu minyak, waktu, dan interval goyang yang benar adalah...', ['Minyak 160°C, 12 menit, goyang tiap 3 menit', 'Minyak 150°C, 8 menit, tanpa digoyang', 'Minyak 175°C, 5 menit, goyang tiap menit', 'Minyak 160°C, 20 menit, goyang tiap 10 menit'], 'A', 'SOP Goreng Ayam: suhu api 175°C, suhu minyak 160°C, 12 menit, goyangkan tiap 3 menit.'),
  pg('k2b', W2, 'Kitchen', JOB, 'HC-SOP-KIT-03', 'Goreng Kulit', 'Berapa berat kulit mentah 50 gr setelah matang, dan berapa kali penepungan?', ['55 gr, 1x tepung', '60 gr, 2x tepung', '60 gr, 1x tepung', '70 gr, 3x tepung'], 'B', 'Goreng Kulit: minyak 150°C, 12 menit, 2x penepungan, 50 gr mentah menjadi 60 gr matang.'),
  pg('k3a', W3, 'Kitchen', JOB, 'HC-SOP-KIT-05', 'Formula Nasi Goreng', 'Formula baku Nasi Goreng 1 porsi yang BENAR adalah...', ['Bumbu eco 20 gr, minyak 15 ml, mix sayur 30 gr, saos ricebowl 15 gr, minyak wijen 2 tetes', 'Bumbu eco 30 gr, minyak 20 ml, mix sayur 20 gr, saos ricebowl 10 gr, minyak wijen 5 tetes', 'Bumbu eco 15 gr, minyak 15 ml, mix sayur 50 gr, saos ricebowl 30 gr, tanpa minyak wijen', 'Bumbu eco 20 gr, minyak 50 ml, mix sayur 30 gr, saos ricebowl 15 gr, minyak wijen 1 sdm'], 'A', 'Formula revisi HC-SOP-KIT-05: bumbu eco 20 gr, minyak 15 ml, mix sayur 30 gr, saos ricebowl 15 gr, minyak wijen 2 tetes. Waktu 3-4 menit per porsi.', 'Sulit'),
  pg('k3b', W3, 'Kitchen', JOB, 'HC-SOP-KIT-05', 'Urutan Nasi Goreng', 'Setelah bawang putih geprek ditumis harum, bahan apa yang dimasukkan lebih dulu?', ['Nasi', 'Bumbu eco', 'Mix vegetable 30 gr', 'Saos ricebowl'], 'C', 'Urutan: minyak 15 ml, bawang putih harum, mix vegetable, nasi (api sedang), bumbu eco, saos ricebowl, minyak wijen.'),
  pg('k4a', W4, 'Kitchen', JOB, 'HC-SOP-KIT-06', 'Telur Dadar', 'Komposisi baku telur dadar adalah...', ['1 butir telur, garam 1 gr, minyak 50 ml', '2 butir telur, garam 5 gr, minyak 100 ml', '1 butir telur, tanpa garam, minyak 10 ml', '1 butir telur, garam 10 gr, minyak 20 ml'], 'A', 'HC-SOP-KIT-06: 1 butir telur + garam 1/2 sendok takar (1 gram) + minyak goreng 50 ml, waktu 2 menit.'),
  pg('k4b', W4, 'Kitchen', JOB, 'HC-SOP-KIT-08', 'Kentang Goreng', 'Standar kentang goreng per porsi adalah...', ['Berat 100 gr, minyak 500 ml, 5 menit, bumbu 2,5 gr', 'Berat 200 gr, minyak 500 ml, 10 menit, bumbu 5 gr', 'Berat 100 gr, minyak 100 ml, 2 menit, bumbu 10 gr', 'Berat 50 gr, minyak 500 ml, 5 menit, tanpa bumbu'], 'A', 'HC-SOP-KIT-08: 100 gr, minyak 500 ml, 5 menit, taburan bumbu kentang 2,5 gr (1/2 sdt).'),
  essay('k4e', W4, 'Kitchen', JOB, 'HC-SOP-KIT-02', 'Kualitas Goreng Ayam', 'Jelaskan langkah Anda agar hasil goreng ayam tetap krispi dan matang merata saat jam ramai.', 'Saat rush hour, antrean order panjang dan rekan menyarankan menaikkan suhu minyak agar ayam cepat matang.', ['160', '12 menit', 'goyang', 'dusting', 'standar', 'suhu'], 'Tetap ikuti suhu minyak 160°C selama 12 menit, goyangkan tiap 3 menit, jangan memegang erat ayam saat dusting. Jangan memotong standar demi kecepatan.'),

  // ========================= KASIR =========================
  pg('c1a', W1, 'Kasir', JOB, 'HC-SOP-KAS-01', 'Greeting', 'Kapan kasir wajib menyapa tamu yang datang?', ['Setelah tamu memilih menu', 'Dalam 3 detik pertama', 'Setelah tamu bertanya', 'Setelah selesai menghitung kas'], 'B', 'HC-SOP-KAS-01: wajib sapa dalam 3 detik pertama, tanyakan dine in/take away, sebutkan menu ready dan promo best seller.', 'Mudah'),
  pg('c1b', W1, 'Kasir', JOB, 'HC-SOP-KAS-02', 'Taking Order', 'Selain mencatat nama pemesan, apa yang wajib dilakukan kasir saat taking order?', ['Cross-selling menu extra', 'Menutup laci kas', 'Menolak pesanan tambahan', 'Menunggu tamu bertanya promo'], 'A', 'Taking Order maksimal 45 detik dan wajib cross-selling menu extra (kulit, kentang, jamur, terong, saus keju).'),
  pg('c2a', W2, 'Kasir', JOB, 'HC-SOP-KAS-03', 'Repeat Order & Kembalian', 'Bagaimana cara memberikan uang kembalian yang benar?', ['Diletakkan di meja kasir', 'Langsung ke tangan pelanggan dengan kedua tangan', 'Dititipkan ke rekan kerja', 'Dilempar ringan agar cepat'], 'B', 'HC-SOP-KAS-03: ulangi pesanan dengan jelas dan berikan kembalian langsung ke tangan pelanggan dengan kedua tangan sopan.', 'Mudah'),
  pg('c2b', W2, 'Kasir', JOB, 'HC-SOP-KAS-04', 'Handling Complain', 'Jika ayam sedang tidak tersedia, istilah yang benar diucapkan kasir adalah...', ['"Ayam kosong, Kak"', '"Ayam habis/sedang dimasak" disertai estimasi waktu tunggu akurat', '"Tidak tahu, tanya dapur saja"', '"Pesan menu lain saja"'], 'B', 'HC-SOP-KAS-04: gunakan istilah "Ayam habis/sedang dimasak", bukan "kosong", dan beri estimasi waktu tunggu yang akurat.'),
  pg('c3a', W3, 'Kasir', JOB, 'HC-SOP-KAS-05', 'Layanan Aplikasi Online', 'Driver online menunggu lebih dari 20 menit. Apa yang wajib diberikan?', ['Diskon 50%', 'Segelas es teh gratis', 'Ayam tambahan', 'Tidak ada, itu risiko driver'], 'B', 'HC-SOP-KAS-05: jika driver menunggu > 20 menit, berikan segelas es teh gratis. Baca note customer dengan teliti.'),
  pg('c3b', W3, 'Kasir', JOB, 'HC-SOP-KAS-06', 'Kroscek Order Online', 'Sebelum kantong order online diserahkan ke driver, kasir wajib...', ['Menimbang pesanan', 'Kroscek fisik item dengan struk aplikasi 100%', 'Memfoto pesanan untuk pribadi', 'Menanyakan nama driver saja'], 'B', 'HC-SOP-KAS-06: kroscek fisik item dengan struk aplikasi 100% (sekitar 1 menit) untuk mencegah orderan tertukar.'),
  pg('c4a', W4, 'Kasir', JOB, 'HC-SOP-KAS-07', 'Selisih Kas', 'Selisih uang kas fisik dibanding laporan sistem pada saat closing harus...', ['Maksimal Rp 5.000', 'Rp 0', 'Boleh asal ditutup dari kantong sendiri', 'Dicatat saja tanpa dicek'], 'B', 'HC-SOP-KAS-07: selisih kas fisik vs sistem wajib Rp 0 dan seluruh nota pengeluaran distaples ke buku rekapan harian.'),
  pg('c4b', W4, 'Kasir', JOB, 'HC-SOP-KAS-08', 'Stock Opname', 'Ayam goreng sisa hari ini sebaiknya...', ['Dijual lagi besok dengan harga diskon', 'Tidak dijual esok hari, dan bahan memakai prinsip FIFO/FEFO', 'Disimpan di chiller 1 minggu', 'Dibagikan ke pelanggan tanpa catatan'], 'B', 'HC-SOP-KAS-08: ayam goreng sisa dilarang dijual esok hari; terapkan FIFO dan FEFO.'),
  essay('c4e', W4, 'Kasir', JOB, 'HC-SOP-KAS-09', 'Setoran dan Integritas Kas', 'Jelaskan langkah Anda saat closing agar kas, nota, dan setoran aman dan tercatat benar.', 'Saat closing, uang kas fisik berbeda dengan laporan sistem, padahal Anda sudah lelah dan ingin segera pulang.', ['selisih', 'cek ulang', 'nota', 'rekapan', 'setoran', 'bukti transfer', 'lapor'], 'Cek ulang hitungan, cocokkan nota pengeluaran, laporkan ke SPV/Kepala Outlet bila selisih tidak ketemu. Setoran tepat waktu ke rekening resmi dan simpan bukti transfer fisik dan digital.'),

  // ========================= GEPREK =========================
  pg('g1a', W1, 'Geprek', JOB, 'HC-SOP-GPK-12', 'Label Nashville', 'Warna label level kepedasan Nashville: Biru, Kuning, Merah secara berurutan adalah...', ['Lv 3, Lv 2, Lv 1', 'Lv 1, Lv 2, Lv 3', 'Lv 2, Lv 3, Lv 1', 'Lv 1, Lv 3, Lv 2'], 'B', 'HC-SOP-GPK-12: Biru = Lv 1, Kuning = Lv 2, Merah = Lv 3, wajib ditempel di setiap box menu Nashville.', 'Mudah'),
  pg('g1b', W1, 'Geprek', JOB, 'HC-SOP-GPK-11', 'Penyajian Geprek', 'Penyajian ayam geprek yang benar adalah...', ['Ayam digeprek halus jadi bubur, sambal dicampur', 'Digeprek mantap tidak hancur, 2 slice timun segar, sambal pisah pakai cup sambung', 'Tanpa timun, sambal di atas ayam', 'Ayam utuh tanpa digeprek'], 'B', 'HC-SOP-GPK-11: ayam digeprek mantap (tidak jadi bubur), wajib 2 slice timun segar, sambal dipisah pakai cup sambung.'),
  pg('g2a', W2, 'Geprek', JOB, 'HC-SOP-GPK-03', 'Sambal Bawang', 'Aturan pembuatan sambal bawang adalah...', ['Diblender halus, minyak 100 ml', 'Diuleg manual, bawang digoreng layu 3-5 menit, siram minyak panas 60 ml, porsi 30 gr', 'Diblender sebentar, tanpa minyak', 'Diuleg manual, minyak 75 ml, porsi 50 gr'], 'B', 'HC-SOP-GPK-03: wajib diuleg manual (dilarang diblender), goreng layu 3-5 menit, minyak panas 60 ml, 30 gr per porsi.', 'Sulit'),
  pg('g2b', W2, 'Geprek', JOB, 'HC-SOP-GPK-04', 'Penyajian Terong', '1 porsi terong krispi terdiri dari...', ['5 slice terong + 2 saus', '10 slice terong krispi + 1 saus cabai', '10 slice terong + tanpa saus', '15 slice terong + 1 saus'], 'B', 'HC-SOP-GPK-04: 1 porsi = 10 slice terong krispi + 1 saus cabai.'),
  pg('g3a', W3, 'Geprek', JOB, 'HC-SOP-GPK-06', 'Nashville Potong', 'Pencelupan bumbu Nashville potong yang benar adalah...', ['Bumbu 30 gr, rendam 1 menit, tiriskan, boncabe 1 gr', 'Bumbu 65 gr, rendam 5 menit', 'Bumbu 30 gr, rendam 10 menit', 'Tanpa tiris, langsung packing'], 'A', 'HC-SOP-GPK-06: bumbu celupan 30 gr, rendam 1 menit, tiriskan, tabur boncabe 1 gr, alas plastik nashville, beri label level.'),
  pg('g3b', W3, 'Geprek', JOB, 'HC-SOP-GPK-07', 'AU Nashville', 'Saus keju pada penyajian AU Nashville harus...', ['Dituang di atas ayam', 'Diberikan 2 porsi terpisah dari piring/box ayam utuh', 'Dicampur ke nasi', 'Tidak wajib'], 'B', 'HC-SOP-GPK-07: bumbu 65 gr, boncabe 15 gr, 2 porsi saus keju wajib terpisah; posisi ayam tidak terlentang.'),
  pg('g4a', W4, 'Geprek', JOB, 'HC-SOP-GPK-21', 'Take Away Minuman', 'Aturan plastik untuk order take away adalah...', ['Makanan dan minuman boleh satu plastik', 'Makanan dan minuman diplastik terpisah, panas dan dingin juga dipisah', 'Minuman panas dan dingin satu plastik', 'Tanpa plastik'], 'B', 'HC-SOP-GPK-21: minuman dan makanan wajib diplastik terpisah; minuman panas dan dingin juga dipisah.'),
  pg('g4b', W4, 'Geprek', JOB, 'HC-SOP-GPK-19', 'Pesanan Partai Besar', 'DP minimal untuk pesanan partai besar adalah...', ['10%', '25%', '50%', '100%'], 'C', 'HC-SOP-GPK-19: DP minimal 50% wajib masuk rekening outlet; catat 10 poin data pemesan di nota manual 2 rangkap.'),
  essay('g4e', W4, 'Geprek', JOB, 'HC-SOP-GPK-22', 'Handling Komplain', 'Jelaskan cara Anda menangani tamu yang komplain level pedas Nashville tidak sesuai pesanan.', 'Tamu mengatakan pesanannya Lv 1 tetapi label di box Merah (Lv 3) dan tamu terlihat marah.', ['minta maaf', 'tidak berdebat', 'ganti', 'segera', 'label', 'kartu', 'catat'], 'Dilarang berdebat. Ganti baru segera (kurang dari 3 menit), cek label dan varian, serta catat di kartu penanganan keluhan.'),

  // ========================= HELPER =========================
  pg('h1a', W1, 'Helper', JOB, 'HC-SOP-HLP-01', 'Jenis Lap', 'Lap meja makan boleh dipakai untuk meja geprek/dapur.', ['Boleh jika dicuci dulu', 'Dilarang mencampur lap meja makan dengan lap meja geprek/dapur', 'Boleh saat sepi', 'Boleh jika warna sama'], 'B', 'HC-SOP-HLP-01: dilarang mencampur lap; kanebo hanya untuk alat makan.', 'Mudah'),
  pg('h1b', W1, 'Helper', JOB, 'HC-SOP-HLP-04', 'Clean Up Meja', 'Kapan meja boleh dibersihkan, dan batas waktunya setelah tamu pergi?', ['Saat tamu masih makan; maksimal 10 menit', 'Setelah tamu pergi; maksimal 2 menit', 'Saat tamu masih duduk; tidak ada batas', 'Menunggu jam closing'], 'B', 'HC-SOP-HLP-04: jangan membersihkan meja saat tamu masih makan; maksimal 2 menit setelah tamu pergi, meja kering bebas minyak.'),
  pg('h2a', W2, 'Helper', JOB, 'HC-SOP-HLP-03', 'Cairan Pembersih', 'Perbandingan pel lantai yang benar adalah...', ['1:1', '1:3 air', '1:10 air', '1:50 air'], 'B', 'HC-SOP-HLP-03: pel lantai 1:3 air; noda membandel 1:10 air hangat.'),
  pg('h2b', W2, 'Helper', JOB, 'HC-SOP-HLP-14', 'Menyapu dan Mengepel', 'Arah menyapu/mengepel yang benar adalah...', ['Dari pintu keluar ke sudut terdalam', 'Dari sudut terdalam ke arah pintu keluar', 'Acak', 'Dari tengah ke pinggir'], 'B', 'HC-SOP-HLP-14: mulai dari sudut terdalam ke pintu keluar; peras pel tidak terlalu basah agar lantai tidak licin.'),
  pg('h3a', W3, 'Helper', JOB, 'HC-SOP-HLP-06', 'Slow Cooker', 'Saat membersihkan slow cooker, yang WAJIB dilakukan adalah...', ['Merendam mesin dalam air', 'Mencabut kabel dan tidak merendam mesin', 'Menggosok panci keramik dengan kawat', 'Membersihkan sambil menyala'], 'B', 'HC-SOP-HLP-06: kabel wajib dicabut; dilarang merendam mesin; panci keramik dilarang digosok kawat.'),
  pg('h3b', W3, 'Helper', JOB, 'HC-SOP-HLP-10', 'Showcase', 'Bunga es pada showcase...', ['Dicongkel dengan benda tajam', 'Tidak boleh dicongkel benda tajam; jarak dinding minimal 16 cm', 'Dibiarkan', 'Disiram air panas dari luar'], 'B', 'HC-SOP-HLP-10: dilarang mencongkel bunga es dengan benda tajam; jarak dinding minimal 16 cm untuk sirkulasi kompresor.'),
  pg('h4a', W4, 'Helper', JOB, 'HC-SOP-HLP-07', 'Genset', 'Genset wajib dipanasi...', ['Setiap hari 5 menit', '1 minggu sekali selama 15 menit', '1 bulan sekali 1 menit', 'Hanya saat listrik padam'], 'B', 'HC-SOP-HLP-07: panasi 1 minggu sekali 15 menit, bensin minimal 2 liter, matikan sekring utama PLN sebelum beralih ke genset.'),
  pg('h4b', W4, 'Helper', JOB, 'HC-SOP-HLP-12', 'Kebersihan Mushola', 'Alat bersih-bersih mushola harus...', ['Sama dengan dapur', 'Sapu dan pel KHUSUS mushola; mukena dicuci tiap 2 minggu', 'Sama dengan dining', 'Tidak perlu khusus'], 'B', 'HC-SOP-HLP-12: gunakan sapu dan pel khusus mushola, cuci mukena tiap 2 minggu.'),
  essay('h4e', W4, 'Helper', JOB, 'HC-SOP-HLP-04', 'Clean Up Saat Ramai', 'Jelaskan urutan kerja Anda saat banyak meja kotor sementara tamu baru terus datang.', 'Antrean tamu panjang, ada 6 meja kotor, sebagian tamu masih duduk.', ['prioritas', 'tamu pergi', '2 menit', 'lap', 'kering', 'kursi', 'rapi', 'kerja sama'], 'Bersihkan meja hanya setelah tamu pergi dengan target maksimal 2 menit, pakai lap yang benar, pastikan meja kering bebas minyak dan kursi rapi; koordinasi dengan tim.'),

  // ========================= SOP UMUM (SEMUA JOBDESK) =========================
  pg('u1a', W1, 'Semua', VISI, undefined, 'Nilai H.A.R.A', 'Nilai budaya H.A.R.A Hara Chicken adalah...', ['Halal, Amanah, Responsif, Adaptif', 'Hebat, Aktif, Ramah, Andal', 'Hemat, Awet, Rapi, Aman', 'Hangat, Asli, Ramah, Atraktif'], 'A', 'H.A.R.A = Halal, Amanah, Responsif, Adaptif.', 'Mudah'),
  pg('u1b', W1, 'Semua', ATUR, undefined, 'Grooming', 'Penampilan kerja yang sesuai standar adalah...', ['Seragam kotor asal cepat', 'Seragam bersih, apron, topi/hairnet, tanpa aksesoris berlebih', 'Aksesoris bebas', 'Tanpa topi saat di dapur'], 'B', 'Aturan grooming: seragam bersih, apron, topi/hairnet, tanpa aksesoris berlebih.', 'Mudah'),
  karakter('u1k', W1, KARK, 'Rush Hour', 'Jam makan siang sangat ramai, antrean panjang, dan rekan kerja Anda kewalahan.', 'Apa yang paling mungkin Anda lakukan?', [
    { teks: 'Membantu rekan sambil tetap mengikuti SOP', dimensi: 'kerjasama_tim', poin: 5, deskripsi: 'Kooperatif dan disiplin' },
    { teks: 'Fokus pekerjaan sendiri saja', dimensi: 'kerjasama_tim', poin: 2, deskripsi: 'Cenderung individual' },
    { teks: 'Mempercepat dengan melewati beberapa langkah SOP', dimensi: 'disiplin_sop', poin: 1, deskripsi: 'Mengorbankan standar demi kecepatan' },
    { teks: 'Meminta SPV mengatur pembagian tugas', dimensi: 'ketahanan_stres', poin: 4, deskripsi: 'Tenang dan komunikatif' },
  ]),
  pg('u2a', W2, 'Semua', KARK, undefined, 'Integritas', 'Anda menemukan rekan makan ayam sisa tanpa izin. Sikap yang benar adalah...', ['Diam saja', 'Ikut makan', 'Mengingatkan dan melaporkan sesuai prosedur', 'Memviralkan di media sosial'], 'C', 'Zero tolerance terhadap makan tanpa izin/pencurian; laporkan sesuai prosedur kepada atasan.'),
  pg('u2b', W2, 'Semua', ATUR, undefined, 'Absensi dan Disiplin', 'Jika berhalangan masuk shift, kru wajib...', ['Tidak datang tanpa kabar', 'Menghubungi atasan/SPV sebelum shift dimulai', 'Mengabari setelah seminggu', 'Menitip pesan ke teman besoknya'], 'B', 'Tata tertib: izin disampaikan sebelum shift agar jadwal bisa digantikan.'),
  karakter('u2k', W2, KARK, 'Komplain Tamu', 'Tamu komplain dengan nada tinggi karena menunggu lama.', 'Apa respons Anda?', [
    { teks: 'Mendengarkan, minta maaf, lalu menawarkan solusi', dimensi: 'fokus_pelanggan', poin: 5, deskripsi: 'Empati dan solutif' },
    { teks: 'Membela diri dan menjelaskan alasan panjang', dimensi: 'fokus_pelanggan', poin: 2, deskripsi: 'Defensif' },
    { teks: 'Menyuruh tamu bicara dengan SPV', dimensi: 'ketahanan_stres', poin: 3, deskripsi: 'Menghindari konflik' },
    { teks: 'Mengabaikan', dimensi: 'integritas', poin: 1, deskripsi: 'Tidak bertanggung jawab' },
  ]),
  pg('u3a', W3, 'Semua', VISI, undefined, 'Amanah', 'Contoh sikap Amanah di outlet adalah...', ['Menjaga aset dan kas perusahaan dengan jujur', 'Mengambil bahan sedikit untuk pribadi', 'Mengubah catatan agar terlihat bagus', 'Menyembunyikan kesalahan'], 'A', 'Amanah berarti dapat dipercaya: menjaga aset perusahaan dan mencatat dengan jujur.', 'Mudah'),
  pg('u3b', W3, 'Semua', ATUR, undefined, 'FIFO dan Kebersihan', 'Prinsip FIFO artinya...', ['First In First Out: bahan masuk lebih dulu dipakai lebih dulu', 'Fast In Fast Out', 'Fresh In First Out', 'Final Item First Order'], 'A', 'FIFO: bahan yang masuk lebih dulu dipakai lebih dulu agar kualitas terjaga (HC-SOP-KAS-08).'),
  karakter('u3k', W3, KARK, 'Kesalahan Sendiri', 'Anda tidak sengaja salah menakar bahan sehingga satu porsi harus dibuang.', 'Apa yang Anda lakukan?', [
    { teks: 'Melapor jujur dan membuat ulang sesuai standar', dimensi: 'integritas', poin: 5, deskripsi: 'Jujur dan bertanggung jawab' },
    { teks: 'Tetap menyajikan agar tidak rugi', dimensi: 'disiplin_sop', poin: 1, deskripsi: 'Mengabaikan standar' },
    { teks: 'Membuang diam-diam', dimensi: 'integritas', poin: 2, deskripsi: 'Kurang transparan' },
    { teks: 'Menyalahkan alat', dimensi: 'integritas', poin: 1, deskripsi: 'Menghindar tanggung jawab' },
  ]),
  pg('u4a', W4, 'Semua', VISI, undefined, 'Responsif dan Adaptif', 'Sikap Responsif berarti...', ['Menunggu diperintah', 'Sigap menanggapi kebutuhan tamu dan tim', 'Menunda sampai sepi', 'Hanya melayani yang dikenal'], 'B', 'Responsif: cepat dan tanggap terhadap kebutuhan tamu dan rekan kerja.', 'Mudah'),
  pg('u4b', W4, 'Semua', ATUR, undefined, 'Higiene Kru', 'Kapan kru wajib mencuci tangan?', ['Hanya saat selesai bekerja', 'Sebelum bekerja, setelah dari toilet, dan setelah memegang bahan mentah', 'Hanya jika terlihat kotor', 'Tidak wajib'], 'B', 'Higiene dasar: cuci tangan sebelum kerja, setelah toilet, dan setelah menyentuh bahan mentah.'),
  karakter('u4k', W4, KARK, 'Beda Pendapat Tim', 'Rekan senior meminta Anda melakukan langkah yang berbeda dari SOP.', 'Bagaimana sikap Anda?', [
    { teks: 'Menghormati, lalu menjelaskan SOP dan mengonfirmasi ke SPV', dimensi: 'disiplin_sop', poin: 5, deskripsi: 'Sopan dan taat standar' },
    { teks: 'Menurut saja', dimensi: 'disiplin_sop', poin: 2, deskripsi: 'Kurang tegas pada standar' },
    { teks: 'Berdebat di depan tamu', dimensi: 'ketahanan_stres', poin: 1, deskripsi: 'Kurang kontrol emosi' },
    { teks: 'Mengabaikan perintah dan pergi', dimensi: 'kerjasama_tim', poin: 1, deskripsi: 'Tidak kooperatif' },
  ]),
];

// Data awal hasil ujian: dikosongkan agar tidak ada data palsu masuk ke laporan.
export const INITIAL_HASIL_UJIAN_MINGGUAN: HasilUjianKruMingguan[] = [];

/**
 * Soal ujian per minggu. ISOLASI KETAT:
 * hanya soal jobdesk milik divisi kru + soal SOP Umum (divisi 'Semua').
 * Tidak ada soal dari stasiun/jobdesk lain.
 */
export function getSoalUjianByMinggu(minggu: ExamWeek, divisi: Division): SoalUjianMingguan[] {
  const weekPool = BANK_SOAL_MINGGUAN.filter((s) => s.minggu === minggu);
  const jobdeskSoal = weekPool.filter((s) => s.divisi === divisi);
  const umumSoal = weekPool.filter((s) => s.divisi === 'Semua');
  return [...jobdeskSoal, ...umumSoal];
}

export interface ProfilKarakterEvaluasi {
  integritas: number;
  ketahanan_stres: number;
  fokus_pelanggan: number;
  disiplin_sop: number;
  kerjasama_tim: number;
  tipe_kepribadian_kerja: string;
  kesimpulan_trainer: string;
  rekomendasi_pendampingan: string;
}

export interface AnalisisPilarHasil {
  sop_jobdesk: number;
  peraturan_perusahaan: number;
  karakter_integritas: number;
  visi_misi_hara: number;
  pilar_terendah: string;
  rekomendasi_coaching: string;
  materi_rekomendasi: string[];
}

const DIMENSI_LABEL: Record<Dimensi, string> = {
  integritas: 'Integritas',
  ketahanan_stres: 'Ketahanan Stres',
  fokus_pelanggan: 'Fokus Pelanggan',
  disiplin_sop: 'Disiplin SOP',
  kerjasama_tim: 'Kerja Sama Tim',
};

const TIPE_KERJA: Record<Dimensi, string> = {
  integritas: 'Pilar Amanah & Jujur',
  ketahanan_stres: 'Penjaga Ritme Tahan Tekanan',
  fokus_pelanggan: 'Pelayan Berorientasi Tamu',
  disiplin_sop: 'Pilar Disiplin & Pelaksana Teliti',
  kerjasama_tim: 'Penggerak Kerja Sama Tim',
};

/** Hitung profil karakter dari jawaban soal KARAKTERISTIK_PSIKOLOGIS (0-100 per dimensi). */
export function hitungProfilPsikologis(answers: Record<string, string>): ProfilKarakterEvaluasi {
  const totals: Record<Dimensi, { sum: number; n: number }> = {
    integritas: { sum: 0, n: 0 },
    ketahanan_stres: { sum: 0, n: 0 },
    fokus_pelanggan: { sum: 0, n: 0 },
    disiplin_sop: { sum: 0, n: 0 },
    kerjasama_tim: { sum: 0, n: 0 },
  };

  BANK_SOAL_MINGGUAN.filter((q) => q.tipe === 'KARAKTERISTIK_PSIKOLOGIS').forEach((q) => {
    const picked = q.opsi?.find((o) => o.label === answers[q.id]);
    if (picked?.profil_trait) {
      const t = picked.profil_trait;
      totals[t.dimensi].sum += t.poin;
      totals[t.dimensi].n += 1;
    }
  });

  const score = (d: Dimensi) => (totals[d].n > 0 ? Math.round((totals[d].sum / totals[d].n / 5) * 100) : 60);
  const profil = {
    integritas: score('integritas'),
    ketahanan_stres: score('ketahanan_stres'),
    fokus_pelanggan: score('fokus_pelanggan'),
    disiplin_sop: score('disiplin_sop'),
    kerjasama_tim: score('kerjasama_tim'),
  };

  const dims = Object.keys(profil) as Dimensi[];
  const kuat = dims.reduce((a, b) => (profil[b] > profil[a] ? b : a), dims[0]);
  const lemah = dims.reduce((a, b) => (profil[b] < profil[a] ? b : a), dims[0]);

  return {
    ...profil,
    tipe_kepribadian_kerja: TIPE_KERJA[kuat],
    kesimpulan_trainer: `Kekuatan utama kru ada pada ${DIMENSI_LABEL[kuat]} (${profil[kuat]}%). Dimensi yang perlu dikuatkan: ${DIMENSI_LABEL[lemah]} (${profil[lemah]}%).`,
    rekomendasi_pendampingan: `Beri coaching singkat dan observasi lapangan pada dimensi ${DIMENSI_LABEL[lemah]} melalui simulasi situasi nyata di outlet.`,
  };
}

const PILAR_LABEL: Record<PilarKompetensi, string> = {
  sop_jobdesk: 'SOP Jobdesk & Teknis',
  peraturan_perusahaan: 'Peraturan Perusahaan & Kas',
  karakter_integritas: 'Karakter & Integritas',
  visi_misi_hara: 'Visi & Misi Budaya H.A.R.A',
};

/** Hitung radar 4 pilar kompetensi + rekomendasi coaching dari jawaban kru. */
export function hitungAnalisisPilar(
  answers: Record<string, string>,
  questions: SoalUjianMingguan[]
): AnalisisPilarHasil {
  const pilars: PilarKompetensi[] = ['sop_jobdesk', 'peraturan_perusahaan', 'karakter_integritas', 'visi_misi_hara'];
  const skor: Record<PilarKompetensi, number> = {
    sop_jobdesk: 0,
    peraturan_perusahaan: 0,
    karakter_integritas: 0,
    visi_misi_hara: 0,
  };

  pilars.forEach((p) => {
    let got = 0;
    let max = 0;
    questions
      .filter((q) => q.pilar_kompetensi === p)
      .forEach((q) => {
        if (q.tipe === 'PILIHAN_GANDA') {
          max += q.bobot;
          if (answers[q.id] === q.jawaban_benar) got += q.bobot;
        } else if (q.tipe === 'ESSAY_HOTS') {
          max += q.bobot;
          const ans = (answers[q.id] || '').toLowerCase();
          if (ans.trim().length > 15) {
            const kw = q.kata_kunci_essay || [];
            const hits = kw.filter((k) => ans.includes(k.toLowerCase())).length;
            const ratio = kw.length > 0 ? Math.min(1, hits / Math.max(2, kw.length * 0.6)) : 0.8;
            got += q.bobot * ratio;
          }
        } else if (q.tipe === 'KARAKTERISTIK_PSIKOLOGIS') {
          max += 5;
          const poin = q.opsi?.find((o) => o.label === answers[q.id])?.profil_trait?.poin ?? 0;
          got += poin;
        }
      });
    skor[p] = max > 0 ? Math.round((got / max) * 100) : 0;
  });

  const terendah = pilars.reduce((a, b) => (skor[b] < skor[a] ? b : a), pilars[0]);

  const MATERI: Record<PilarKompetensi, string[]> = {
    sop_jobdesk: ['Review SOP jobdesk sesuai kode SOP yang salah dijawab', 'Praktik terbimbing di stasiun kerja bersama trainer'],
    peraturan_perusahaan: ['Tata tertib, absensi, dan grooming', 'Prosedur kas, FIFO/FEFO, dan higiene'],
    karakter_integritas: ['Studi kasus integritas dan kejujuran', 'Simulasi menangani komplain dan tekanan jam sibuk'],
    visi_misi_hara: ['Pemahaman nilai H.A.R.A (Halal, Amanah, Responsif, Adaptif)', 'Diskusi visi-misi dan pengalaman Hara Extra'],
  };

  return {
    ...skor,
    pilar_terendah: PILAR_LABEL[terendah],
    rekomendasi_coaching: `Fokuskan coaching pada pilar ${PILAR_LABEL[terendah]} (${skor[terendah]}%), lalu ulangi evaluasi singkat setelah pendampingan.`,
    materi_rekomendasi: MATERI[terendah],
  };
}
